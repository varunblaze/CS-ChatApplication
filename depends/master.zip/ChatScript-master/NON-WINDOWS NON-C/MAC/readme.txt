1 Copy MacCompile.sh from the MAC directory to the top level ChatScript directory
1a Insure Curl librarys are installed on your machine: http://curl.haxx.se/download.html OR
1b disable Json functions by #define DISCARDJSON 1 or similar compiler directive 
2 Run MacCompile in a terminal window
3 In terminal window run ./BINARIES/ChatScript local to try it out