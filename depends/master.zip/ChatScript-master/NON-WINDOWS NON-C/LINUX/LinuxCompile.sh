cd ../SRC/; make server

!// or cd ../SRC/; make pgserver



