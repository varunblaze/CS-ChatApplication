cd ChatScript
nohup ./ChatScript 2>nohup.log &

