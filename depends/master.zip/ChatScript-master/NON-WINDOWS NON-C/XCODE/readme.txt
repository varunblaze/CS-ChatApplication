Latest CS versions use C++11: make these changes to XCODE project

Project settings -> Build Settings and set C++ Language Dialect to C++11 
C++ Standard Library to libc++ (LLVM C++ standard library with C++11 support)