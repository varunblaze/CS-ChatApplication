This foreign dictionary comes from Treetagger.  http://www.cis.uni-muenchen.de/~schmid/tools/TreeTagger/

Note that for commercial use, you will need to get a license, at which point you will be able to use the
pos-tagger integrated into CS directly.  Contact Bruce Wilcox if you need to arrange a license. The
cost is on the order of 1,000 Euro or so per language for life.


  ************************
                  ** TreeTagger License **
                  ************************

1. The Institut fuer maschinelle Sprachverarbeitung, Universitaet
   Stuttgart, subsequently called ``the licenser'', grants you (the
   licensee) the rights to use the TreeTagger software subsequently
   called ``the system'' for evaluation, research and teaching
   purposes. Any other usage of the system (in particular for
   commercial purposes) is forbidden.

2. The licensee has no right to give or sell the system to third
   parties without written permission from the licenser.

3. The licenser has no obligation to maintain the system.
   Nevertheless the licensee is encouraged to report to the licenser
   any problems with or suggestions for improvement of the system.

4. The licenser has no obligation to make new releases available to the
   licensee, but where such updates are supplied they shall be governed by
   the terms of this agreement.

			   NO WARRANTY

5. BECAUSE THE SYSTEM IS LICENSED FREE OF CHARGE, WE PROVIDE
ABSOLUTELY NO WARRANTY, TO THE EXTENT PERMITTED BY APPLICABLE STATE
LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE LICENSER PROVIDES THE
SYSTEM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK
AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH THE LICENSEE.
SHOULD THE SYSTEM PROVE DEFECTIVE, THE LICENSEE ASSUMES THE COST OF
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

6. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW WILL THE LICENSER BE
LIABLE TO THE LICENSEE FOR DAMAGES, INCLUDING ANY LOST PROFITS, LOST
MONIES, OR OTHER SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE (INCLUDING BUT NOT LIMITED TO LOSS
OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY THIRD
PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAM)
THE PROGRAM, EVEN IF THE LICENSEE HAS BEEN ADVISED OF THE POSSIBILITY
OF SUCH DAMAGES, OR FOR ANY CLAIM BY ANY OTHER PARTY.


Contact Adress:

Helmut Schmid
Institut fuer maschinelle Sprachverarbeitung (IMS) 
Universitaet Stuttgart
Azenbergstr. 12
D-70174 Stuttgart, Germany

Helmut.Schmid@ims.uni-stuttgart.de

